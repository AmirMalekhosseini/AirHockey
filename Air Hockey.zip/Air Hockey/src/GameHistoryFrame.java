import javax.swing.*;
import java.awt.*;

public class GameHistoryFrame extends JFrame {

    Box box;
    TextArea textArea;

    GameHistoryFrame() {
        this.setSize(400, 400);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);

        box = Box.createHorizontalBox();
        textArea = new TextArea();
        for (int i = 0; i < MyProject.gameHistory.size(); i++) {
            textArea.setText(textArea.getText() + "Game " + i + 1 + "- " + MyProject.gameHistory.get(i).getGamerTagPlayerOne() + ": " + MyProject.gameHistory.get(i).playerOneScore + "   " + MyProject.gameHistory.get(i).getGamerTagPlayerTwo() + ": " + MyProject.gameHistory.get(i).playerTwoScore + "   " + "Game Mode: " + MyProject.gameHistory.get(i).gameMode + "   Is Game Finish? " + MyProject.gameHistory.get(i).isGameFinished);
        }

        box.add(new JScrollPane(textArea));

    }

}
