import java.util.ArrayList;

public class MyProject {

    public static ArrayList<GameHistory> gameHistory = new ArrayList<>();
    public MyProject() {

        MenuFrame menuFrame = new MenuFrame();

    }

}
